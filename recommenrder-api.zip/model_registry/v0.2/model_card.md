# Model Card v0.2

- **Artifact**: `model.joblib`
- **Produced on**: 2024-10-12
- **Pipeline**: scheduled retraining (milestone 4)
- **Metrics**:
  - HR@20: 0.47
  - NDCG@20: 0.31
- **Notes**: incorporates drift-aware feature refresh and watch engagement labels.
